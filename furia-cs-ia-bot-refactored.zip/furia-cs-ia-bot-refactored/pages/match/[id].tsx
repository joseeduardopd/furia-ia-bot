
// pages/match/[id].tsx
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { useUser } from '../../src/context/UserContext';
import { Layout } from '../../src/components/Layout';

type RoundSummary = string;

const CURRENT_ROSTER = [
  'Mareks "YEKINDAR" Galinskis',
  'Yuri "yuurih" Santos',
  'Kaike "KSCERATO" Cerato',
  'Gabriel "FalleN" Toledo',
  'Danil "molodoy" Golubenko'
];

export default function Match() {
  const router = useRouter();
  const { id, message } = router.query;
  const { user } = useUser();
  const [roundSummaries, setRoundSummaries] = useState<RoundSummary[]>([]);
  const [displayCount, setDisplayCount] = useState(0);

  useEffect(() => {
    if (!user) {
      router.replace('/');
      return;
    }
    if (id === 'demo') {
      // Gera 13 summaries fictícios baseados no roster
      const demoRounds: RoundSummary[] = Array.from({ length: 13 }, (_, i) => {
        const p1 = CURRENT_ROSTER[i % CURRENT_ROSTER.length];
        const p2 = CURRENT_ROSTER[(i + 1) % CURRENT_ROSTER.length];
        return `Round ${i + 1}:\n• ${p1} garantiu o primeiro kill decisivo.\n• ${p2} fechou o round com clutch impressionante.`;
      });
      setRoundSummaries(demoRounds);

      // Exibe um a um até 13
      let idx = 0;
      setDisplayCount(1);
      const interval = setInterval(() => {
        idx += 1;
        setDisplayCount(prev => Math.min(prev + 1, demoRounds.length));
        if (idx >= demoRounds.length - 1) clearInterval(interval);
      }, 3000);
      return () => clearInterval(interval);
    }
    // lógica real de socket.io permanece se não for demo
  }, [id, user, router]);

  return (
    <Layout>
      {/* Mensagem de validação */}
      {typeof message === 'string' && (
        <div className="mb-4 p-4 rounded bg-green-100 text-green-800">
          {message}
        </div>
      )}

      {/* Exibição dos rounds 1 a displayCount */}
      {roundSummaries.length ? (
        <div className="space-y-6">
          {roundSummaries.slice(0, displayCount).map((txt, idx) => (
            <pre
              key={idx}
              className="bg-gray-50 p-4 rounded whitespace-pre-line"
            >
              {txt}
            </pre>
          ))}
        </div>
      ) : (
        <p>Carregando partida...</p>
      )}
    </Layout>
  );
}