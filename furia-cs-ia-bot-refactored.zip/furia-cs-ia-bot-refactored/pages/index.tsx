// pages/index.tsx
import Link from 'next/link';
import { Layout } from '../src/components/Layout';

export default function Home() {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-full space-y-6">
        <h1 className="text-3xl font-bold">Bem-vindo, Fã da FURIA!</h1>

        <div className="space-x-4">
          <Link
            href="/chat"
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Chat IA
          </Link>
          <Link
            href="/register"
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            Acompanhar partida
          </Link>
        </div>
      </div>
    </Layout>
  );
}
