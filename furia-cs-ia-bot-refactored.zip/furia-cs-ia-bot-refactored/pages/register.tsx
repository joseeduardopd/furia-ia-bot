import { FormEvent, useState } from 'react';
import { useRouter } from 'next/router';
import { useUser } from '../src/context/UserContext';
import { Layout } from '../src/components/Layout';

/**
 * Page de registro de usuário.
 * Permite cadastro do fã enviando documento para validação via IA.
 * Exibe erros específicos ou mensagem de sucesso.
 */
export default function Register() {
  const { user, register } = useUser();
  const router = useRouter();

  const [fullName, setFullName] = useState('');
  const [cpf, setCpf] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!file) {
      setError('Por favor, envie o documento (PDF ou imagem).');
      return;
    }
    setError(null);
    setSuccess(null);

    const formData = new FormData();
    formData.append('fullName', fullName);
    formData.append('cpf', cpf);
    formData.append('birthDate', birthDate);
    formData.append('document', file);

    try {
      const res = await fetch('/api/validate-doc', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();

      if (!res.ok) {
        // Exibe a mensagem de erro retornada pela API
        setError(data.message || 'Erro na validação. Verifique seus dados.');
        return;
      }

      // Validação bem-sucedida
      setSuccess(data.message || 'Cadastro validado com sucesso!');

      // Salva informações do usuário e redireciona
      register({ fullName, cpf, birthDate, email: '' });
      router.push('/match/demo');
    } catch (networkError) {
      console.error('Erro de rede:', networkError);
      setError('Erro de rede. Tente novamente.');
    }
  }

  // Se já estiver logado, redireciona
  if (user) {
    router.replace('/match/demo');
    return null;
  }

  return (
    <Layout>
      <div className="max-w-md mx-auto">
        <h1 className="text-2xl mb-4">Cadastro de Fã</h1>
        <p className="mb-4 text-gray-700">
          Para acessar a narração resumida por IA a cada round, cadastre-se e envie seus documentos.
        </p>
        {error && <p className="text-red-500 mb-2">{error}</p>}
        {success && <p className="text-green-500 mb-2">{success}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="fullName" className="block font-medium">
              Nome completo
            </label>
            <input
              id="fullName"
              required
              value={fullName}
              onChange={e => setFullName(e.target.value)}
              className="w-full border px-2 py-1"
            />
          </div>
          <div>
            <label htmlFor="cpf" className="block font-medium">
              CPF
            </label>
            <input
              id="cpf"
              required
              value={cpf}
              onChange={e => setCpf(e.target.value)}
              className="w-full border px-2 py-1"
            />
          </div>
          <div>
            <label htmlFor="birthDate" className="block font-medium">
              Data de nascimento
            </label>
            <input
              id="birthDate"
              type="date"
              required
              value={birthDate}
              onChange={e => setBirthDate(e.target.value)}
              className="w-full border px-2 py-1"
            />
          </div>
          <div>
            <label htmlFor="document" className="block font-medium">
              Documento
            </label>
            <input
              id="document"
              type="file"
              accept="application/pdf,image/*"
              onChange={e => setFile(e.target.files ? e.target.files[0] : null)}
              className="w-full"
            />
          </div>
          <button
            type="submit"
            className="w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
          >
            Registrar e Acompanhar
          </button>
        </form>
      </div>
    </Layout>
  );
}
