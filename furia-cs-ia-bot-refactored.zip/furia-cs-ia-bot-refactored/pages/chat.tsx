// pages/chat.tsx
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { useUser } from '../src/context/UserContext';
import { Layout } from '../src/components/Layout';

// Define o formato de cada mensagem
interface Message {
  from: 'user' | 'bot';
  text: string;
}

export default function Chat() {
  const router = useRouter();
  const { user } = useUser();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);

  // Envio da saudação inicial com histórico vazio
  useEffect(() => {
    if (!user) {
      router.replace('/');
      return;
    }
    (async () => {
      const response = await fetch('/api/furia-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: '', history: [] }),
      });
      const { reply } = await response.json();
      setMessages([{ from: 'bot', text: reply }]);
    })();
  }, [user, router]);

  // Função para enviar novas mensagens
  const sendMessage = async () => {
    if (!input.trim()) return;

    // Atualiza histórico local
    const userMsg: Message = { from: 'user', text: input };
    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');

    // Converte para formato da API
    const historyPayload = newHistory.map(m => ({
      role: m.from === 'bot' ? 'assistant' : 'user',
      content: m.text,
    }));

    try {
      const response = await fetch('/api/furia-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg.text, history: historyPayload }),
      });
      const { reply } = await response.json();
      setMessages(prev => [...prev, { from: 'bot', text: reply }]);
    } catch {
      setMessages(prev => [...prev, { from: 'bot', text: 'Erro de conexão. Tente novamente.' }]);
    }
  };

  return (
    <Layout>
      <div className="w-full max-w-sm mx-auto h-[80vh] flex flex-col border border-gray-300 rounded-lg shadow-lg overflow-hidden">
        <div className="bg-black text-white p-3 text-center font-semibold">
          Chat IA - FURIA CS
        </div>
        <div className="flex-1 overflow-auto p-3 bg-white space-y-2">
          {messages.map((msg, idx) => (
            <div key={idx} className={msg.from === 'bot' ? 'text-left' : 'text-right'}>
              <span className={
                msg.from === 'bot'
                  ? 'inline-block bg-gray-200 p-2 rounded'
                  : 'inline-block bg-blue-600 text-white p-2 rounded'
              }>
                {msg.text}
              </span>
            </div>
          ))}
        </div>
        <div className="flex p-2 bg-gray-100">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage()}
            className="flex-1 border rounded-l px-2 py-1"
            placeholder="Digite sua mensagem..."
          />
          <button onClick={sendMessage} className="bg-black text-white px-4 rounded-r">
            Enviar
          </button>
        </div>
      </div>
    </Layout>
  );
}

