import type { NextApiRequest, NextApiResponse } from 'next';
import { IncomingForm } from 'formidable';
import fs from 'fs';
import pdfParse from 'pdf-parse';
import Tesseract from 'tesseract.js';
import { Configuration, OpenAIApi } from 'openai';

/**
 * Disable Next.js body parser to use formidable.
 */
export const config = { api: { bodyParser: false } };

/**
 * Handler for document validation.
 *
 * Validates user input (fullName, cpf, birthDate) against the uploaded document (PDF or image).
 * Returns JSON: { valid: boolean, message: string }.
 */
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ valid: false, message: 'Method not allowed' });
  }

  const form = new IncomingForm({ keepExtensions: true });
  form.parse(req, async (err, fields, files) => {
    if (err) {
      return res.status(500).json({ valid: false, message: 'Erro ao processar arquivo.' });
    }

    const fullName = String((fields as any).fullName || '').trim();
    const cpf = String((fields as any).cpf || '').trim();
    const birthDate = String((fields as any).birthDate || '').trim();

    const docField = (files as any).document;
    const file = Array.isArray(docField) ? docField[0] : docField;
    if (!file) {
      return res.status(400).json({ valid: false, message: 'Documento não enviado.' });
    }

    const filePath = file.filepath;
    const mimeType = file.mimetype || '';

    let extractedText = '';
    try {
      if (mimeType === 'application/pdf') {
        const buffer = fs.readFileSync(filePath);
        const pdfData = await pdfParse(buffer);
        extractedText = pdfData.text;
      } else if (mimeType.startsWith('image/')) {
        const { data: { text } } = await Tesseract.recognize(filePath, 'por');
        extractedText = text;
      } else {
        return res.status(400).json({ valid: false, message: 'Tipo de arquivo não suportado.' });
      }
    } catch (error) {
      console.error('Extração de texto falhou:', error);
      return res.status(500).json({ valid: false, message: 'Falha ao extrair texto do documento.' });
    }

    const systemPrompt = 'Você é um sistema que verifica se as informações fornecidas batem com o documento anexado.';
    const userPrompt = `Documento extraído:
"""
${extractedText}
"""

Campos informados:
- Nome completo: ${fullName}
- CPF: ${cpf}
- Data de nascimento: ${birthDate}

Responda apenas em JSON com a estrutura:
{ "valid": boolean, "message": "mensagem de erro ou sucesso" }`;

    const configuration = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
    const openai = new OpenAIApi(configuration);

    try {
      const completion = await openai.createChatCompletion({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0,
      });

      const reply = completion.data.choices?.[0]?.message?.content?.trim() || '';
      let result: { valid: boolean; message: string };

      try {
        result = JSON.parse(reply);
      } catch (parseError) {
        console.error('Erro ao parsear resposta IA:', parseError, 'Reply:', reply);
        return res.status(500).json({ valid: false, message: 'Resposta da IA em formato inválido.' });
      }

      if (result.valid) {
        return res.status(200).json({ valid: true, message: result.message });
      } else {
        return res.status(400).json({ valid: false, message: result.message });
      }
    } catch (error) {
      console.error('Erro ao validar com IA:', error);
      return res.status(500).json({ valid: false, message: 'Erro ao validar com IA.' });
    }
  });
}
