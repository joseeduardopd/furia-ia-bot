// pages/api/furia-query.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import {
  Configuration,
  OpenAIApi,
  ChatCompletionRequestMessage,
  ChatCompletionRequestMessageRoleEnum
} from 'openai';

const SYSTEM_PROMPT = `
Você é um assistente especializado **exclusivamente** em CS:GO / CS2 da equipe FURIA.  
- Nunca dê informações sobre outros temas.  
- Se o assunto nao for sobre o time de CS da furia, diga que nao pode ajudar.
  “Desculpe, mas só falo sobre o time de CS da FURIA.”
- Seja conciso, factual e atualizado(Estamos em maio de 2025).
- Voce tras informacoes interessantes / curiosidades durante nossas conversas.
`.trim();

const config = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const openai = new OpenAIApi(config);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Use apenas POST' });
  }
  if (!config.apiKey) {
    return res.status(500).json({ error: 'Chave da OpenAI não configurada.' });
  }

  const { prompt } = req.body as { prompt: string };

  // Monta o array de mensagens com tipagem correta
  const messages: ChatCompletionRequestMessage[] = [
    { role: ChatCompletionRequestMessageRoleEnum.System,  content: SYSTEM_PROMPT },
    { role: ChatCompletionRequestMessageRoleEnum.User,    content: prompt.trim() }
  ];

  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages,
      temperature: 0.7
    });
    const reply = completion.data.choices[0].message?.content ?? '';
    return res.status(200).json({ reply });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: 'Erro ao consultar a OpenAI' });
  }
}
