// pages/api/ai-query.ts
import { NextApiRequest, NextApiResponse } from 'next';
import {
  Configuration,
  OpenAIApi,
  ChatCompletionRequestMessage,
  ChatCompletionRequestMessageRoleEnum
} from 'openai';

// Prompt especializado, com o ano corrente forçado a 2025
const SYSTEM_PROMPT = `
Você é um assistente virtual fanático pela FURIA.
- Sempre forneça as informações mais recentes e atualizadas sobre partidas, estatísticas e notícias.
- Ano atual: 2025. Use eventos e datas a partir de 2025.
- Ao iniciar a conversa, diga “Bom dia/Boa tarde/Boa noite” baseado no horário do servidor.
- Em seguida, pergunte como pode ajudar em relação ao time de CS da FURIA.
`.trim();

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Data e hora do servidor (São Paulo) para contexto adicional
  const now = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });

  if (!configuration.apiKey) {
    return res.status(500).json({ error: 'OpenAI API key not configured.' });
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Recebe do cliente: o prompt atual e o histórico da conversa
  const { prompt, history = [] } = req.body as {
    prompt: string;
    history?: ChatCompletionRequestMessage[];
  };

  // Monta a lista de mensagens, sempre começando pelo System Prompt
  const messages: ChatCompletionRequestMessage[] = [
    {
      role: ChatCompletionRequestMessageRoleEnum.System,
      content: SYSTEM_PROMPT + `\nData atual: ${now}`
    },
    // Em seguida, todo o histórico de user/bot
    ...history,
    // Por fim, a nova pergunta do usuário
    {
      role: ChatCompletionRequestMessageRoleEnum.User,
      content: prompt.trim()
    }
  ];

  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages,
      temperature: 0.8
    });
    const reply = completion.data.choices[0].message?.content || '';
    return res.status(200).json({ reply });
  } catch (err: any) {
    console.error('OpenAI error:', err);
    return res.status(500).json({ error: 'Erro ao consultar a IA' });
  }
}
