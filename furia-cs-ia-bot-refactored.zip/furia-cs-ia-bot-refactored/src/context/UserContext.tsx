import { createContext, ReactNode, useContext, useState } from 'react';

interface User {
  fullName: string;
  cpf: string;
  email: string;
  birthDate: string;
}

interface UserContextType {
  user: User | null;
  register: (u: User) => void;
}

const UserContext = createContext<UserContextType>({ user: null, register: () => {} });

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const register = (u: User) => setUser(u);
  return <UserContext.Provider value={{ user, register }}>{children}</UserContext.Provider>;
}

export const useUser = () => useContext(UserContext);
