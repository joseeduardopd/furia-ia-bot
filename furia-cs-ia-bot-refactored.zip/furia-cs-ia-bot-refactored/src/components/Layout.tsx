import Link from 'next/link';
import { ReactNode } from 'react';

interface LayoutProps { children: ReactNode; }

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header preto com navegação via Link */}
      <header className="bg-black px-6 py-3">
        <nav className="flex space-x-4">
          <Link href="/" className="text-white hover:underline">
            Home
          </Link>
          <Link href="/chat" className="text-white hover:underline">
            Chat IA
          </Link>
        </nav>
      </header>

      {/* Conteúdo principal */}
      <main className="flex-1 p-6 flex flex-col items-center justify-center">
        {children}
      </main>

      {/* Rodapé */}
      <footer className="bg-gray-100 text-center py-4">
        <p className="text-sm text-gray-600">
          © {new Date().getFullYear()} FURIA e-sports. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  );
}